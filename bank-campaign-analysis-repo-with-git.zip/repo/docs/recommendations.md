# Recommendations

Actionable next steps derived from the [major findings](findings.md).

## 1. Prioritize cellular outreach
Shift remaining telephone / unknown-channel contacts to cellular where possible. Cellular contact is associated with a ~20-point higher conversion share.

## 2. Coach agents for longer, deeper calls
Build scripts and training around the ~9-minute engagement window seen in subscribers, rather than optimizing purely for call volume or speed-to-close.

## 3. Target low-debt segments first
Prioritize clients without an existing housing loan. For clients who do carry a housing loan, pair outreach with tailored, lower-commitment offers rather than a standard term-deposit pitch.

## 4. Re-engage prior successful clients
Build a dedicated re-contact list from clients with a successful previous campaign outcome — this is the single strongest repeat-conversion signal in the data.

## 5. Tailor messaging by occupation
Lead with management, retired, and admin segments, which convert well. Adapt the value proposition for blue-collar clients (e.g. flexibility, smaller minimum deposits, simpler onboarding).

## 6. Plan staffing around May seasonality
Increase call-center capacity ahead of May — the peak-volume month for both groups — to capture demand without sacrificing call quality, since quality (duration) is more predictive than volume alone.

## Suggested Follow-Up Analysis

- Segment conversion rate by combinations of factors (e.g. cellular contact **and** no housing loan) rather than single variables in isolation.
- Model expected call duration needed for conversion by job/education segment to right-size agent time investment.
- Investigate the "unknown" contact-channel and "unknown" previous-outcome categories — closing this data gap could materially improve targeting precision.
