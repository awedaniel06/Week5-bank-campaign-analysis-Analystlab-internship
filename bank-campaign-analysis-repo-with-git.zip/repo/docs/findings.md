# Major Findings

Detailed write-up of the six major findings from comparing the subscriber (n=5,289) and non-subscriber (n=5,873) dashboards.

## 1. Call duration is the strongest signal

Subscribers averaged **537.18 seconds** per call vs. **223.13 seconds** for non-subscribers — a 2.4x gap. Longer, more engaged conversations track closely with conversion, more strongly than any single demographic factor.

## 2. Cellular outreach outperforms other channels

**82.6%** of subscribers were reached via cellular vs. **62.5%** of non-subscribers. Non-subscribers also saw roughly 3x more "unknown" contact-channel records (30.92% vs 10.0%), pointing to either a data-quality gap or genuinely harder-to-reach clients on other channels.

## 3. Household debt load matters

**63.4%** of subscribers carry no existing housing loan, versus only **43.0%** of non-subscribers. Conversely, 56.97% of non-subscribers do have a housing loan compared to just 36.59% of subscribers. Existing loan obligations appear to reduce appetite for committing to a new term deposit.

## 4. Occupation shapes conversion likelihood

| Job | Subscriber share | Non-subscriber share |
|---|---|---|
| Management | 24.60% | 21.54% |
| Technician | 15.88% | 16.74% |
| Blue-Collar | 13.39% | 21.05% |
| Admin. | 11.93% | 11.97% |
| Retired | 9.76% | 4.46% |
| Services | 6.98% | 9.43% |

Blue-collar workers are the most over-represented group among non-subscribers — the largest gap of any occupation. Retired clients show the opposite pattern, converting well above their non-subscriber share.

## 5. Prior campaign success predicts future success

Clients with a **successful previous campaign outcome** appear far more often among subscribers. Non-subscribers are dominated by "unknown" and "failure" previous-outcome categories, suggesting a track record of engagement (or lack thereof) carries forward.

## 6. May is the seasonal peak

Both groups saw their highest contact volume in May (17.49% of subscribers, 32.33% of non-subscribers). Non-subscriber volume is more heavily concentrated in a handful of months (May, Jul, Aug, Jun), while subscriber volume is spread more evenly across the year — suggesting that timing alone doesn't drive conversion, and that off-peak contacts may convert at a comparatively higher rate.
