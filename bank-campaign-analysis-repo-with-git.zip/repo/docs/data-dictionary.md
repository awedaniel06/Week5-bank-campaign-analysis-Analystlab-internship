# Data Dictionary

Field definitions for the metrics and categories shown in the subscriber / non-subscriber dashboards. This dataset reflects a standard bank term-deposit marketing campaign structure (client demographics, financial indicators, and contact history).

| Field | Type | Description |
|---|---|---|
| `outcome` | categorical | Whether the client subscribed to a term deposit (`subscriber` / `non-subscriber`). Used to split the two dashboards. |
| `duration` | numeric (seconds) | Length of the last contact call with the client. |
| `balance` | numeric (currency) | Client's average yearly account balance. |
| `age` | numeric (years) | Client's age at time of contact. |
| `job` | categorical | Client's occupation category — Management, Technician, Blue-Collar, Admin., Retired, Services, Student, Unemployed, Self-Employed, Entrepreneur, Housemaid, Unknown. |
| `marital` | categorical | Marital status — Married, Single, Divorced. |
| `education` | categorical | Highest education level — Primary, Secondary, Tertiary, Unknown. |
| `housing` | boolean | Whether the client has an existing housing loan (Yes/No). |
| `loan` | boolean | Whether the client has an existing personal loan (Yes/No). |
| `contact` | categorical | Contact communication channel — Cellular, Telephone, Unknown. |
| `month` | categorical | Calendar month of last contact (Jan–Dec). |
| `poutcome` | categorical | Outcome of the previous marketing campaign — Success, Failure, Other, Unknown. |

## Dashboard Summary Metrics

Each dashboard also surfaces pre-aggregated KPIs, derived from the fields above:

| Metric | Derivation |
|---|---|
| Avg Duration | Mean of `duration` within the group |
| Conversion Rate / Decline Rate | Group count ÷ total contacts (5,289 / 5,873 of 11,162) |
| Avg Balance | Mean of `balance` within the group |
| Avg Age | Mean of `age` within the group |
| Month Name — Total / Percentage | Count and share of contacts per `month` |
| Job — Total / Percentage | Count and share of contacts per `job` |

## Notes

- This repository documents the dashboard as provided (image-based export); no raw row-level CSV/dataset is included here.
- If the underlying dataset is added later, place it under a `data/` directory and update this dictionary with exact column names, types, and null-handling rules.
